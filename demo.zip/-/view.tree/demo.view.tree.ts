namespace $ { export class $mol_app_taxon_demo extends $mol_app_taxon {

	/// hierarhyField \name
	hierarhyField() {
		return "name"
	}

} }

